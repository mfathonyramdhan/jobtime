<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>JobTime - Edit Akun User</title>
	<link rel="icon" type="image/x-icon" href="assets/images/logo/favicon.ico" />

	<link rel="preconnect" href="https://fonts.gstatic.com" />
	<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet" />
	<link rel="stylesheet" href="assets/css/bootstrap.css" />

	<link rel="stylesheet" href="assets/vendors/simple-datatables/style.css" />

	<link rel="stylesheet" href="assets/vendors/perfect-scrollbar/perfect-scrollbar.css" />
	<link rel="stylesheet" href="assets/vendors/bootstrap-icons/bootstrap-icons.css" />
	<link rel="stylesheet" href="assets/css/app.css" />
	<link rel="shortcut icon" href="assets/images/favicon.svg" type="image/x-icon" />
</head>

<body>
	<div id="app">
		<div id="sidebar" class="active">
			<div class="sidebar-wrapper active">
				<div class="sidebar-header">
					<div class="d-flex justify-content-between">
						<div class="logo">
							<a href="index.html"><img src="assets/images/logo/logo.png" alt="Logo" srcset="" /></a>
						</div>
						<div class="toggler">
							<a href="#" class="sidebar-hide d-xl-none d-block"><i class="bi bi-x bi-middle"></i></a>
						</div>
					</div>
				</div>
				<div class="sidebar-menu">
					<ul class="menu">
						<li class="sidebar-title">Admin Menu</li>

						<li class="sidebar-item">
							<a href="index.html" class="sidebar-link">
								<i class="bi bi-grid-fill"></i>
								<span>Dashboard</span>
							</a>
						</li>

						<li class="sidebar-item active has-sub">
							<a href="#" class="sidebar-link">
								<i class="bi bi-person-badge-fill"></i>
								<span>Manajemen Akun</span>
							</a>
							<ul class="submenu" style="display: block">
								<li class="submenu-item">
									<a href="data-akun-admin.html">Data Akun Admin</a>
								</li>
								<li class="submenu-item active">
									<a href="data-akun-user.html">Data Akun User</a>
								</li>
							</ul>
						</li>

						<li class="sidebar-item has-sub">
							<a href="#" class="sidebar-link">
								<i class="bi bi-file-earmark-spreadsheet-fill"></i>
								<span>Manajemen Loker</span>
							</a>
							<ul class="submenu">
								<li class="submenu-item">
									<a href="data-loker.html">Data Loker</a>
								</li>
							</ul>
						</li>
					</ul>
				</div>
				<button class="sidebar-toggler btn x">
					<i data-feather="x"></i>
				</button>
			</div>
		</div>

		<div id="main">
			<header class="mb-3">
				<a href="#" class="burger-btn d-block">
					<i class="bi bi-justify fs-3"></i>
				</a>
			</header>

			<div class="page-heading">
				<div class="page-title">
					<div class="row">
						<div class="col-12 col-md-6 order-md-1 order-last">
							<h3>Edit Data Akun User</h3>
							<!-- <p class="text-subtitle text-muted">
									Tampilan edit data akun user (nama user)
								</p> -->
						</div>
						<div class="col-12 col-md-6 order-md-2 order-first">
							<nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
								<ol class="breadcrumb">
									<li class="breadcrumb-item">
										<a href="index.html">Dashboard</a>
									</li>
									<li class="breadcrumb-item">
										<a href="data-akun-user.html">Manajemen Akun - Data Akun User</a>
									</li>
									<li class="breadcrumb-item active" aria-current="page">
										Edit Data Akun User
									</li>
								</ol>
							</nav>
						</div>
					</div>
				</div>

				<section id="basic-vertical-layouts">
					<div class="row match-height">
						<div class="col">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">Edit Data Akun User</h4>
								</div>
								<div class="card-content">
									<div class="card-body">
										<form class="form form-vertical">
											<div class="form-body">
												<div class="row">
													<div class="divider divider-left">
														<div class="divider-text">
															<strong>(1/3) Informasi Akun</strong>
														</div>
													</div>
													<div class="col-md-auto">
														<div class="form-group has-icon-left">
															<label for="first-name-icon">Nama Lengkap</label>
															<div class="position-relative">
																<input type="text" class="form-control" placeholder="Input nama lengkap baru" id="first-name-icon" />
																<div class="form-control-icon">
																	<i class="bi bi-person"></i>
																</div>
															</div>
														</div>
													</div>
													<div class="col-md-auto">
														<div class="form-group has-icon-left">
															<label for="email-id-icon">Email</label>
															<div class="position-relative">
																<input type="text" class="form-control" placeholder="Input email baru" id="email-id-icon" />
																<div class="form-control-icon">
																	<i class="bi bi-envelope"></i>
																</div>
															</div>
														</div>
													</div>
													<div class="col-md-auto">
														<div class="form-group has-icon-left">
															<label for="password-id-icon">Password</label>
															<div class="position-relative">
																<input type="password" class="form-control" placeholder="Input password baru" id="password-id-icon" />
																<div class="form-control-icon">
																	<i class="bi bi-lock"></i>
																</div>
															</div>
														</div>
													</div>
													<div class="divider divider-left">
														<div class="divider-text">
															<strong>(2/3) Informasi Pribadi</strong>
														</div>
													</div>
													<div class="row">
														<div class="col-md-auto">
															<div class="form-group has-icon-left">
																<label for="mobile-id-icon">No. HP</label>
																<div class="position-relative">
																	<input type="text" class="form-control" placeholder="Input nomor hp. baru" id="mobile-id-icon" />
																	<div class="form-control-icon">
																		<i class="bi bi-phone"></i>
																	</div>
																</div>
															</div>
														</div>
														<div class="col-md-auto">
															<div class="form-group has-icon-left">
																<label for="date-id-icon">Tanggal Lahir</label>
																<div class="position-relative">
																	<input type="date" class="form-control" placeholder="Update tanggal lahir" id="date-id-icon" />
																	<div class="form-control-icon">
																		<i class="bi bi-calendar"></i>
																	</div>
																</div>
															</div>
														</div>
														<div class="col-md-auto">
															<div class="form-group has-icon-left">
																<label for="#">Jenis Kelamin</label>
																<div class="position-relative">
																	<select class="form-select" id="basicSelect">
																		<option>Laki - Laki</option>
																		<option>Perempuan</option>
																	</select>
																</div>
															</div>
														</div>
														<div class="col-4">
															<div class="form-group">
																<label for="formFile">Foto</label>
																<input type="file" class="form-control" placeholder="" id="formFile" />
															</div>
														</div>
													</div>
													<div class="divider divider-left">
														<div class="divider-text">
															<strong>(3/3) Informasi Tempat Tinggal</strong>
														</div>
													</div>
													<div class="col-md-auto">
														<div class="form-group has-icon-left">
															<label for="#">Provinsi</label>
															<div class="position-relative">
																<input type="text" class="form-control" placeholder="Input provinsi baru" id="#" />
																<div class="form-control-icon">
																	<i class="bi bi-map"></i>
																</div>
															</div>
														</div>
													</div>
													<div class="col-md-auto">
														<div class="form-group has-icon-left">
															<label for="#">Kota</label>
															<div class="position-relative">
																<input type="text" class="form-control" placeholder="Input kota baru" id="#" />
																<div class="form-control-icon">
																	<i class="bi bi-pin-map"></i>
																</div>
															</div>
														</div>
													</div>
													<!-- <div class="col-md-auto">
															<div class="form-group has-icon-left">
																<label for="#">Kecamatan</label>
																<div class="position-relative">
																	<input
																		type="text"
																		class="form-control"
																		placeholder="Input kecamatan baru"
																		id="#"
																	/>
																	<div class="form-control-icon">
																		<i class="bi bi-geo"></i>
																	</div>
																</div>
															</div>
														</div>
														<div class="col-md-auto">
															<div class="form-group has-icon-left">
																<label for="#">Desa</label>
																<div class="position-relative">
																	<input
																		type="text"
																		class="form-control"
																		placeholder="Input desa baru"
																		id="#"
																	/>
																	<div class="form-control-icon">
																		<i class="bi bi-geo-alt"></i>
																	</div>
																</div>
															</div>
														</div> -->
													<div class="col-md-8">
														<div class="form-group has-icon-left">
															<label for="#">Alamat</label>
															<div class="position-relative">
																<input type="text" class="form-control" placeholder="Input alamat baru" id="#" />
																<div class="form-control-icon">
																	<i class="bi bi-signpost-2"></i>
																</div>
															</div>
														</div>
													</div>
													<div class="divider divider-left">
														<div class="divider-text">
															<strong>*)</strong> Silahkan periksa data anda
															sebelum klik Submit!
														</div>
													</div>
													<div class="col-12 d-flex justify-content-end">
														<button type="reset" class="btn btn-light-secondary me-1 mb-1">
															Reset
														</button>
														<button type="submit" class="btn btn-primary me-1 mb-1">
															Submit
														</button>
													</div>
												</div>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
			</div>

			<footer>
				<div class="footer clearfix mb-0 text-muted">
					<div class="float-start">
						<p>2022 &copy; Copyright - JobTime</p>
					</div>
				</div>
			</footer>
		</div>
	</div>
	<script src="assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script src="assets/js/bootstrap.bundle.min.js"></script>
	<script>
		$(function() {
			$("#datetimepicker1").datetimepicker();
		});
	</script>
	<script src="assets/js/main.js"></script>
</body>

</html>