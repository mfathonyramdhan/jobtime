<body>
  <div class="page-heading">
    <h3>Statistik JobTime</h3>
  </div>
  <div class="page-content">
    <section class="row">
      <div class="col">
        <div class="row">
          <div class="col">
            <div class="card">
              <div class="card-body px-3 py-4-5">
                <div class="row">
                  <div class="col-md-4">
                    <div class="stats-icon purple">
                      <i class="iconly-boldProfile"></i>
                    </div>
                  </div>
                  <div class="col-md-8">
                    <h6 class="text-muted font-semibold">Total User</h6>
                    <h6 class="font-extrabold mb-0"><?= $jumlah_user ?></h6>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card">
              <div class="card-body px-3 py-4-5">
                <div class="row">
                  <div class="col-md-4">
                    <div class="stats-icon blue">
                      <i class="iconly-boldShow"></i>
                    </div>
                  </div>
                  <div class="col-md-8">
                    <h6 class="text-muted font-semibold">Total Loker</h6>
                    <h6 class="font-extrabold mb-0"><?= $jumlah_loker ?></h6>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card">
              <div class="card-body px-3 py-4-5">
                <div class="row">
                  <div class="col-md-4">
                    <div class="stats-icon green">
                      <i class="iconly-boldShow"></i>
                    </div>
                  </div>
                  <div class="col-md-8">
                    <h6 class="text-muted font-semibold">
                      Loker Belum direview
                    </h6>
                    <h6 class="font-extrabold mb-0"><?= $jumlah_loker_status1 ?></h6>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col">
        <div class="card">
          <div class="card-body py-4 px-5">
            <div class="d-flex align-items-center">
              <div class="avatar avatar-xl">
                <img src="<?php echo base_url('assets/images/foto_profil/') . $data_user['foto'] ?>" alt="Admin Photo Profile" />
              </div>
              <div class="ms-3 name">
                <h5 class="font-bold">Halo, Admin</h5>
                <h6 class="text-muted mb-0"><?= $data_user['nama'] ?></h6>
              </div>
            </div>
          </div>
        </div>
        </div>
          <!-- <div class="col-6 col-lg-3 col-md-6">
                  <div class="card">
                    <div class="card-body px-3 py-4-5">
                      <div class="row">
                        <div class="col-md-4">
                          <div class="stats-icon red">
                            <i class="iconly-boldBookmark"></i>
                          </div>
                        </div>
                        <div class="col-md-8">
                          <h6 class="text-muted font-semibold">Saved Post</h6>
                          <h6 class="font-extrabold mb-0">112</h6>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> -->
        </div>
        

        <!-- <div class="card">
          <div class="card-header">
            <h4>Users Chart</h4>
          </div>
          <div class="card-body">
            <canvas id="pie"></canvas>
          </div>
        </div> -->
      </div>
        <div class="row">
          <div class="col">
            <div class="card">
              <div class="card-header">
                <h4>Grafik Loker 2022</h4>
              </div>
              <div class="card-body">
                <div class="container">
                  <div class="row">
                    <div class="col-12">
                      <!-- <canvas id="bar" hight="100"> -->
                      <canvas id="myChart" width="400" height="200"></canvas>
                      </canvas>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
       
      </div>
     
    </section>
  </div>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.8.0/chart.min.js" integrity="sha512-sW/w8s4RWTdFFSduOTGtk4isV1+190E/GghVffMA9XczdJ2MDzSzLEubKAs5h0wzgSJOQTRYyaz73L3d6RtJSg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <!-- <script>
    const baseUrl = "<?php echo base_url(); ?>"
    const myChart = (chartType) => {
      $.ajax({
        url: baseUrl + 'admin/chart_data',
        dataType: 'json',
        method: 'get',
        success: data => {
          
          let chartX = []
          let chartY = []

          data.map(data => {
            chartX.push(<?php echo json_encode($bulan) ?>)
            chartY.push(<?php echo json_encode($jumlah) ?>)
          })
          const chartData = {
            labels: chartX,
            datasets: [{
              label: 'Sales',
              data: chartY,
              backgroundColor: ['lightcoral'],
              borderColor: ['lightcoral'],
              borderWidth: 4

            }]
          }
          const ctx = document.getElementById(chartType).getContext('2d')
          const config = {
            type: chartType,
            data: chartData
          }
          switch (chartType) {
            case 'pie':
              const pieColor = ['salmon', 'red', 'green', 'blue', 'aliceblue', 'pink', 'orange', 'gold', 'plum', 'darkcyan', 'wheat', 'silver']
              chartData.datasets[0].backgroundColor = pieColor
              chartData.datasets[0].borderColor = pieColor
              break;
            case 'bar':
              chartData.datasets[0].backgroundColor = ['skyblue']
              chartData.datasets[0].borderColor = ['skyblue']
              break;
            default:
              config.options = {
                scales: {
                  y: {
                    beginAtZero: true
                  }
                }
              }

          }

          const chart = new Chart(ctx, config)
        }
      })
    }

    myChart('pie')
    // myChart('line')
    myChart('bar')
  </script> -->
  
<?php 
$con = new mysqli('localhost', 'root', '', 'jobtime');
$query = $con->query("SELECT MONTHNAME(jobs_created_at) as monthname, COUNT(id_jobs) as jumlahloker FROM tb_jobs GROUP BY monthname  ORDER BY `jumlahloker` DESC");

foreach($query as $data)
{
  $monthname[] = $data['monthname'];
  $jumlahloker[] = $data['jumlahloker'];
}
?>

<script>

const labels = <?php echo json_encode($monthname)?>;
const data = {
  labels: labels,
  datasets: [{
    label: 'Jumlah Loker',
    data: <?php echo json_encode($jumlahloker)?>,
    backgroundColor: [
      'rgba(255, 99, 132, 0.2)',
      'rgba(255, 159, 64, 0.2)',
      'rgba(255, 205, 86, 0.2)',
      'rgba(75, 192, 192, 0.2)',
      'rgba(54, 162, 235, 0.2)',
      'rgba(153, 102, 255, 0.2)',
      'rgba(201, 203, 207, 0.2)'
    ],
    borderColor: [
      'rgb(255, 99, 132)',
      'rgb(255, 159, 64)',
      'rgb(255, 205, 86)',
      'rgb(75, 192, 192)',
      'rgb(54, 162, 235)',
      'rgb(153, 102, 255)',
      'rgb(201, 203, 207)'
    ],
    borderWidth: 1
  }]
};

const config = {
  type: 'bar',
  data: data,
  options: {
    scales: {
      y: {
        beginAtZero: true
      }
    }
  },
};

var myChart = new Chart(
  document.getElementById('myChart'),
  config
);

</script>


</body>
<footer>
  <div class="footer clearfix mb-0 text-muted">
    <div class="float-start">
      <p>2022 &copy; Copyright - JobTime</p>
    </div>
  </div>
</footer>
</div>
</div>